UPDATE Answer SET is_valid = '1' WHERE answer_text = '���' AND question_num = 21
SELECT * FROM Answer WHERE answer_text = '���' AND question_num = 21
SELECT * FROM History WHERE attribute_id = 13 