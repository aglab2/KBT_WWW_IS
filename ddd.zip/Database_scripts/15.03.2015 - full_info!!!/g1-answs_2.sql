﻿-- Enter the Analyser name in format {G1 | G1.1 | G1.2 | G2 | G3}.{xml | bin}
-- use extension .xml to build a new, .bin to load existing Analyser
-- Building Analyser using G1.2\G1.2.xml...	
-- Ok!
-- Great! Enter the name of the directory or the file to process:	MEGATEST

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D509-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D510-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D511-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D512-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D513-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D514-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D515-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D516-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D517-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D518-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D519-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C003-0-19.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I509-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I510-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\R001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\R501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P509-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P510-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F509-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F510-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F511-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F512-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F513-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F514-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F515-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\I601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N103-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N105-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N114-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N115-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N116-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N117-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N118-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PU.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PU.zip_temp.txt\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='Корона',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='Яблока',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Желудок',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='Берлин',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Зебра',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Тимон и Пумба',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='Черный Квадрат',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='Христофор Колумб',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='буква F',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='Синица и Журавль',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Лошадь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='Прошлое,будущее',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='Ломоносов',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='Клиффорд',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='Икар',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Нити',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='Ватикан',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Ресницы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Счет',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Александр',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='Перископ',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Великий, могучий',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='Масляное',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Чадо',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N201-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N202-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N203-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N204-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N205-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N206-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N207-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N208-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N209-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N210-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C033-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C034-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C035-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C036-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C037-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C038-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\R003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\R005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P513-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\I601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\Q501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E006-1-12.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='Уфа, Нью ЙОРК',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='Звонки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Тарелочек для стрельбы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='Трубка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Гринвуд',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Якоря',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='От быка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='Танго',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='л',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='Тролли',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Снежный человек',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='Мертвые души',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='Чипсы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='Светик- семицветик',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='Волшебник из страны ОЗ',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Собаки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='Джоконда',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Афина',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Шляпы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Река',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='Молния',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Потеря сознания',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='Молчание',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Яйцо Фаберже',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C033-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C034-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C035-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C036-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C037-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C038-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P506-1-22.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P507-1-22.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P513-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\I601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N105-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N114-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\Q501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='Фукс',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='Коровы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Калигуд',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='Человек-паук',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Нож и масло',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Вавилон',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='Супермаркет',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='Банкоматы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='Врунгель',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='Дуров',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Трогательный',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='Муми-тролль',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='Гиганская Гавань',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='Млечный путь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='Винсент ван Гог',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Нос Сфинкса',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='Почерк',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Белоснежка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Сахарная вата',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Раскраска',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='Телевизор',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Карлсон',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='Школа',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Один шаг',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N201-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N202-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N203-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N204-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N205-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N207-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N208-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N210-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C033-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C034-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C035-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C036-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C037-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C038-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\I601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N105-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N114-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N601.txt ----------------

exec addAnswerByGlobalID @regcard_number='N601',@question_num='36',@answer_text='у доски',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='35',@answer_text='английский американский',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='34',@answer_text='ложь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='33',@answer_text='помощник пилота',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='32',@answer_text='Великие озера',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='31',@answer_text='прокладка железной дороги',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='30',@answer_text='фон',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='29',@answer_text='лето',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='28',@answer_text='28 долларов',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='27',@answer_text='-',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='26',@answer_text='пианино арфа',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='25',@answer_text='голова',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='24',@answer_text='Нобель',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='23',@answer_text='животное',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='22',@answer_text='окулист',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='21',@answer_text='Дарвин',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='20',@answer_text='мудрых мыслей',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='19',@answer_text='пиковая',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='18',@answer_text='обогреватель',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='17',@answer_text='веревки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='16',@answer_text='вилки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='15',@answer_text='виноградники',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='14',@answer_text='Джордж Клуни',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='13',@answer_text='грязь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='12',@answer_text='комедия',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='11',@answer_text='Марк',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='10',@answer_text='Париж',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='9',@answer_text='носорог',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='8',@answer_text='парламент',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='7',@answer_text='эскизов',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='6',@answer_text='микрофон',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='5',@answer_text='столица Австралии',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='4',@answer_text='вилки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='3',@answer_text='борис акунин',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='2',@answer_text='пеньята',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N601',@question_num='1',@answer_text='книги сказок',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N603.txt ----------------

exec addAnswerByGlobalID @regcard_number='N603',@question_num='36',@answer_text='адресная строка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='35',@answer_text='английский американский',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='34',@answer_text='решетка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='33',@answer_text='командир корабля',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='32',@answer_text='Ньюфаундленд',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='31',@answer_text='I мировая война',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='30',@answer_text='точка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='29',@answer_text='света',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='28',@answer_text='7 евро',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='27',@answer_text='-',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='26',@answer_text='Орфей Эвридика',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='25',@answer_text='повязка на глаз',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='24',@answer_text='объединения германии',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='23',@answer_text='домашнее животное',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='22',@answer_text='дантист',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='21',@answer_text='череп',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='20',@answer_text='московского метрополитена',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='19',@answer_text='дуэль',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='18',@answer_text='пылесос',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='17',@answer_text='чехлы',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='16',@answer_text='эпитафии',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='15',@answer_text='сады',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='14',@answer_text='Дариен Шэн',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='13',@answer_text='афродита',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='12',@answer_text='башня',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='11',@answer_text='Карл',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='10',@answer_text='Все дороги ведут в Париж',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='9',@answer_text='шаман',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='8',@answer_text='кредит',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='7',@answer_text='город',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='6',@answer_text='фонарь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='5',@answer_text='Австралия',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='4',@answer_text='золото',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='3',@answer_text='филдинг',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='2',@answer_text='мешок с деньгами',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='N603',@question_num='1',@answer_text='счастливое рождество',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\Q501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='Эппл',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='На рукаве',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Загадать желание',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='Перья',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Тыква',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Зеркало',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='Шекспир',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='Мерседес',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='Вольфрам',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='остров Пасхи',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Зима, Блины',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='Горбун',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='Молчали',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='Гитара',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='Медведи',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Крылов',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='в медведя',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Винни- Пух',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Извилины',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Человек в футляре',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='Гвоздь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Туманный Альбион',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='Колобок',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Чехов',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N201-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N203-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N204-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N205-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N207-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N208-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N210-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C033-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C034-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C035-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C036-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C037-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C038-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IV.zip_temp.txt\IV\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IV.zip_temp.txt\IV\R003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P513-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N105-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N114-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\pu.zip_temp.txt\pu\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\pu.zip_temp.txt\pu\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='Радио',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='Каспийское море',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Тюльпаны',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='полное имя и фамилия',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Струн',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Левостороннее движение',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='редис,морковь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='ХИ',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='ясный',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='Ядро',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Гензель и Гретель',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='фобии',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='дымить',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='стекла',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='1660',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Вай фай',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='По горизонтали',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Хамелеон',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Русалочка',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Тарантино',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='откроет глаза',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Парабола',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='на бис',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Плечо',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N201-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N202-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N203-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N204-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N205-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N207-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N208-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N210-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D520-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C023-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C026-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C027-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C028-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C029-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C031-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C032-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C033-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C034-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C035-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C036-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C037-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C038-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C508-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\R503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\R504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F505-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F506-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F507-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\I601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L013-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T009-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T012-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T014-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T015-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T016-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T017-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T018-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T019-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T020-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T021-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T022-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T024-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T025-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\!!!README!!!.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\Ans-instr.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N102-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N104-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N105-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N106-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N107-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N108-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N109-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N110-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N111-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N112-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N113-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N114-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N601-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N602-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N603-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\Q001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\Q501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\AnsV.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E001-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E002-1-14.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E002-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E003-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E004-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E005-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E006-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E007-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E008-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E010-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E011-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E501-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E502-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E503-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E504-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\ZM##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\ZV##-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\TO.zip_temp.txt\W101-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\TO.zip_temp.txt\W101.txt ----------------

exec addAnswerByGlobalID @regcard_number='W101',@question_num='24',@answer_text='никак',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='23',@answer_text='от исповеди',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='22',@answer_text='Братья Гримм',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='21',@answer_text='Святой Варлофомей',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='20',@answer_text='Бонд',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='19',@answer_text='Запятую',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='18',@answer_text='Бремен',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='17',@answer_text='Ян Матейко',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='16',@answer_text='ВЫ',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='15',@answer_text='ино',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='14',@answer_text='Флорентианин',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='13',@answer_text='Есть Идея',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='12',@answer_text='Сентябрь',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='11',@answer_text='СЛ',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='10',@answer_text='Обнаженные',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='9',@answer_text='Шарик',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='8',@answer_text='Пушкин',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='7',@answer_text='Божественная комедия',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='6',@answer_text='Замкнутый круг',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='5',@answer_text='Жарких',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='4',@answer_text='Берлинская стена',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='3',@answer_text='Капулетти,Монтеки',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='2',@answer_text='Сони',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'
exec addAnswerByGlobalID @regcard_number='W101',@question_num='1',@answer_text='Папа Римский',@is_valid='0',@tournament_name='14 Чемпионат МО по ЧГК.',@tournament_city='Москва',@gamenumber='1'

-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\AnsM.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N201-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N202-i.txt ----------------


-------------------- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N203-i.txt ----------------



-- TEST RESULTS
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D509-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D510-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D511-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D512-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D513-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D514-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D515-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D516-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D517-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D518-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D519-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C003-0-19.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\DU.zip_temp.txt\C506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I509-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\I510-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\N505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IS.zip_temp.txt\IS\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\R001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\IV.zip_temp.txt\IV\R501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P509-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\P510-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KH.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F509-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F510-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F511-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F512-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F513-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F514-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\F515-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\I601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\LO.zip_temp.txt\LO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PP.zip_temp.txt\T505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N103-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N105-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N114-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N115-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N116-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N117-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N118-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PS.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PU.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\PU.zip_temp.txt\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\ST.zip_temp.txt\E504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\AnsV.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N201-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N202-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N203-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N204-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N205-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N206-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N207-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N208-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N209-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\N210-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t1\raw\VE.zip_temp.txt\VE\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C033-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C034-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C035-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C036-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C037-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C038-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\C506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\DU.zip_temp.txt\DU\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\I5.zip_temp.txt\I5\R503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IS.zip_temp.txt\IS\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\R003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\IV.zip_temp.txt\R005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KA.zip_temp.txt\U004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\P513-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KH.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\F507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\I601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\LO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\P6.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\PP.zip_temp.txt\T504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\ps.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\pu.zip_temp.txt\pu\Q501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E006-1-12.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\E504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\st.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t2\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DO.zip_temp.txt\DO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C033-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C034-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C035-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C036-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C037-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C038-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\C507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\DU.zip_temp.txt\DU\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IS.zip_temp.txt\IS\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\IV.zip_temp.txt\IV\R504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KA.zip_temp.txt\KA\U005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P506-1-22.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P507-1-22.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\P513-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KH.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\F507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\I601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\LO.zip_temp.txt\LO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\PP.zip_temp.txt\T504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N105-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N114-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\ps.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\pu.zip_temp.txt\pu\Q501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\st.zip_temp.txt\E504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N201-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N202-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N203-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N204-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N205-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N207-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N208-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t3\raw\VE.zip_temp.txt\N210-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C033-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C034-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C035-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C036-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C037-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C038-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\C508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\DU.zip_temp.txt\DU\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IS.zip_temp.txt\IS\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\IV.zip_temp.txt\IV\R504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KA.zip_temp.txt\KA\U005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\F507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\I601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\LO.zip_temp.txt\LO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\PP.zip_temp.txt\T504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N105-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N114-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N601.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\N603.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\ps.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\pu.zip_temp.txt\pu\Q501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\St.zip_temp.txt\E504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N201-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N203-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N204-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N205-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N207-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N208-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t4\raw\VE.zip_temp.txt\VE\N210-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DO.zip_temp.txt\DO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C033-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C034-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C035-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C036-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C037-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\C038-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\DU.zip_temp.txt\DU\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\N006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IS.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IV.zip_temp.txt\IV\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\IV.zip_temp.txt\IV\R003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KA.zip_temp.txt\KA\U005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\P513-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KH.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\LO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\PP.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N105-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N114-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\ps.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\pu.zip_temp.txt\pu\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\pu.zip_temp.txt\pu\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\St.zip_temp.txt\E007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N201-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N202-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N203-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N204-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N205-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N207-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N208-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t5\raw\VE.zip_temp.txt\N210-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\D520-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DO.zip_temp.txt\DO\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C023-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C026-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C027-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C028-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C029-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C031-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C032-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C033-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C034-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C035-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C036-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C037-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C038-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\C508-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\DU.zip_temp.txt\DU\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\I503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\EG.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\N006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IS.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\R503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\IV.zip_temp.txt\IV\R504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KA.zip_temp.txt\KA\U005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F505-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F506-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\F507-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\I601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\KO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L013-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\L503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\LO.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PO.zip_temp.txt\K003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T009-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T012-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T014-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T015-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T016-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T017-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T018-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T019-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T020-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T021-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T022-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T024-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T025-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\T504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\PP.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\!!!README!!!.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\Ans-instr.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N102-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N104-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N105-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N106-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N107-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N108-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N109-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N110-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N111-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N112-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N113-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N114-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N601-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N602-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\N603-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\ps.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\Q001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\pu.zip_temp.txt\pu\Q501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\AnsV.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E001-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E002-1-14.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E002-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E003-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E004-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E005-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E006-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E007-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E008-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E010-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E011-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E501-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E502-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E503-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\E504-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\ZM##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\st.zip_temp.txt\ZV##-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\TO.zip_temp.txt\W101-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\TO.zip_temp.txt\W101.txt:True
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\AnsM.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N201-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N202-i.txt:False
-- C:\Users\Кирилл\Desktop\KBT_WWW_IS\Grammar\TestsG1\$\t6\raw\VE.zip_temp.txt\VE\N203-i.txt:False
